<template>
  <div class="light-white-bg py-16">
    <v-container>
      <p class="label grey-color text-uppercase">{{ $t('subtitle') }}</p>
      <h2 class="mt-3 blue-color m-w-480">{{ $t('title') }}</h2>

      <div class="gallery mt-14">
        <div
          v-for="(item, index) in gallery"
          :key="index"
          :data-aos="animations[index % animations.length]"
          data-aos-duration="1000"
          :data-aos-delay="100 * index"
          class="gallery-image one"
          @click="openModal(index)"
        >
          <img v-if="item" class="" :src="item" alt="" />
        </div>
      </div>

      <h2
        v-if="gallery && gallery.length < 1"
        class="blue-color m-w-480 text-center my-16 mx-auto"
      >
        {{ $t('nothing') }}
      </h2>
    </v-container>
    <GallerySwiper ref="swiper" :images="gallery" />
  </div>
</template>

<i18n>
{
  "en": {
    "title": "Photos of our students",
    "subtitle": "Photos",
    "nothing": "Nothing found"
  },
  "ru": {
    "title": "Фотографии наших студентов",
    "subtitle": "Фотогалерея",
    "nothing": "Ничего не найдено"
  }
}
</i18n>

<script>
import Swiper, { Pagination, Navigation, Autoplay } from 'swiper'
Swiper.use([Pagination, Navigation, Autoplay])
export default {
  data: () => ({
    gallery_modal: false,
    animations: ['fade-right', 'fade-down', 'fade-up', 'fade-left'],
    swiperOption: {
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: '.photo-pagination',
        type: 'fraction',
      },
      navigation: {
        nextEl: '.gallery-next',
        prevEl: '.gallery-prev',
      },
    },
    gallery: [
      require('../assets/img/gallery/1.jpg'),
      require('../assets/img/gallery/2.jpg'),
      require('../assets/img/gallery/4.jpg'),
      require('../assets/img/gallery/5.jpg'),
      require('../assets/img/gallery/1.jpg'),
      require('../assets/img/gallery/2.jpg'),
      require('../assets/img/gallery/4.jpg'),
      require('../assets/img/gallery/5.jpg'),
    ],
  }),
  methods: {
    openModal(index) {
      this.$refs.swiper.openModal(index)
    },
  },
}
</script>

<style scoped lang="scss">
.gallery {
  width: 100%;
  // height: 480px;

  overflow-x: scroll;
  // overflow-y: hidden;

  display: grid;
  grid-gap: 24px;
  grid-auto-flow: column;
  // grid-template-column: repeat(2, minmax(200px, auto));
  // grid-template-rows: repeat(2, minmax(228px, auto));
  &-image {
    width: 352px;
    // width: 100%;
    height: 100%;
    max-height: 480px;
    cursor: pointer;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }

  &::-webkit-scrollbar {
    height: 40px;
  }
  &::-webkit-scrollbar-thumb {
    border-bottom: 2px solid #d2840d;
  }
}
</style>
