export { default as Accreditations } from '../..\\components\\Accreditations.vue'
export { default as Achivements } from '../..\\components\\Achivements.vue'
export { default as Calculator } from '../..\\components\\Calculator.vue'
export { default as Carts } from '../..\\components\\Carts.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Gallery } from '../..\\components\\Gallery.vue'
export { default as GallerySwiper } from '../..\\components\\GallerySwiper.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as Hero } from '../..\\components\\Hero.vue'
export { default as Map } from '../..\\components\\Map.vue'
export { default as Partners } from '../..\\components\\Partners.vue'
export { default as Services } from '../..\\components\\Services.vue'
export { default as Study } from '../..\\components\\Study.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
