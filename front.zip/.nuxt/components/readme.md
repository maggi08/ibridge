# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Accreditations>` | `<accreditations>` (components/Accreditations.vue)
- `<Achivements>` | `<achivements>` (components/Achivements.vue)
- `<Calculator>` | `<calculator>` (components/Calculator.vue)
- `<Carts>` | `<carts>` (components/Carts.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Gallery>` | `<gallery>` (components/Gallery.vue)
- `<GallerySwiper>` | `<gallery-swiper>` (components/GallerySwiper.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<Hero>` | `<hero>` (components/Hero.vue)
- `<Map>` | `<map>` (components/Map.vue)
- `<Partners>` | `<partners>` (components/Partners.vue)
- `<Services>` | `<services>` (components/Services.vue)
- `<Study>` | `<study>` (components/Study.vue)
