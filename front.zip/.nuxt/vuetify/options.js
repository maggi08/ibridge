export default {"theme":{"themes":{"light":{"primary":"#D2840D","accent":"#424242","secondary":"#171B2C","info":"#26a69a","warning":"#ffc107","error":"#dd2c00","success":"#00e676"}}}}
